
Flowers_Classification - v3 augmented
==============================

This dataset was exported via roboflow.ai on January 8, 2021 at 12:22 AM GMT

It includes 6921 images.
Flowers are annotated in clip format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 224x224 (Stretch)

The following augmentation was applied to create 5 versions of each source image:
* Randomly crop between 0 and 11 percent of the image
* Random rotation of between -7 and +7 degrees
* Random brigthness adjustment of between -8 and +8 percent
* Random exposure adjustment of between -6 and +6 percent


